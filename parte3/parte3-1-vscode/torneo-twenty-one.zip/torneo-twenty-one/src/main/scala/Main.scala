object Main extends App {

  // Datos iniciales
  val jugadores = List("Alex", "Chen", "Marta", "Sindhu", "Luis")
  val puntuaciones = Array(18, 24, 21, 20, 26)

  // Funciones
  def bust(puntuacion: Int): Boolean = puntuacion > 21

  def estadoMano(puntuacion: Int): String =
    if (bust(puntuacion)) "BUST" else "VALIDA"

  def mejorMano(handA: Int, handB: Int): Int = {
    if (bust(handA) && bust(handB)) 0
    else if (bust(handA)) handB
    else if (bust(handB)) handA
    else if (handA > handB) handA
    else handB
  }

  // Recorre una ronda mostrando cada mano (versión while)
  def procesarRondaWhile(nombres: List[String], puntos: Array[Int]): Unit = {
    var i = 0
    while (i < puntos.length) {
      val nombre = nombres(i)
      val puntuacion = puntos(i)
      println(s"$nombre -> $puntuacion -> ${estadoMano(puntuacion)}")
      i = i + 1
    }
  }

  def contarValidas(puntos: Array[Int]): Int = {
    var contador = 0
    var i = 0
    while (i < puntos.length) {
      if (!bust(puntos(i))) contador = contador + 1
      i = i + 1
    }
    contador
  }

  def contarBust(puntos: Array[Int]): Int = {
    var contador = 0
    var i = 0
    while (i < puntos.length) {
      if (bust(puntos(i))) contador = contador + 1
      i = i + 1
    }
    contador
  }

  def mejorPuntuacionValida(puntos: Array[Int]): Int = {
    var mejor = 0
    var i = 0
    while (i < puntos.length) {
      if (!bust(puntos(i)) && puntos(i) > mejor) mejor = puntos(i)
      i = i + 1
    }
    mejor
  }

  def mostrarResumen(puntos: Array[Int]): Unit = {
    println("--- Resumen de la ronda ---")
    println()
    println(s"Jugadores: ${puntos.length}")
    println(s"Manos válidas: ${contarValidas(puntos)}")
    println(s"Bust: ${contarBust(puntos)}")
    println(s"Mejor puntuación válida: ${mejorPuntuacionValida(puntos)}")
  }

  //RONDA 1
  println("=== Ronda 1 ===")
  procesarRondaWhile(jugadores, puntuaciones)
  println()
  mostrarResumen(puntuaciones)

  //Versión con foreach de la misma ronda
  println()
  println("=== Ronda 1 (versión con foreach) ===")
  puntuaciones.foreach { puntuacion =>
    println(s"$puntuacion -> ${estadoMano(puntuacion)}")
  }

  //RONDA 2
  val puntuacionesRonda2 = Array(22, 19, 20, 21, 17)

  println()
  println("=== Ronda 2 ===")
  procesarRondaWhile(jugadores, puntuacionesRonda2)
  println()
  mostrarResumen(puntuacionesRonda2)

  //Comparación de rondas
  val mejorRonda1 = mejorPuntuacionValida(puntuaciones)
  val mejorRonda2 = mejorPuntuacionValida(puntuacionesRonda2)

  println()
  println("=== Comparación de rondas ===")
  println(s"Mejor puntuación ronda 1: $mejorRonda1")
  println(s"Mejor puntuación ronda 2: $mejorRonda2")

  if (mejorRonda1 > mejorRonda2) {
    println("La ronda 1 tuvo la mejor puntuación.")
  } else if (mejorRonda2 > mejorRonda1) {
    println("La ronda 2 tuvo la mejor puntuación.")
  } else {
    println("Ambas rondas tuvieron la misma mejor puntuación.")
  }
}