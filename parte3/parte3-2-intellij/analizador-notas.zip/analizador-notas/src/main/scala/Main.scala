object Main extends App {

  //Datos iniciales
  val estudiantes = List("Ana", "Luis", "Marta", "Pedro", "Sofia")
  val notas = Array(8, 4, 10, 6, 3)

  //Funciones
  def aprobado(nota: Int): Boolean = nota >= 5

  def estadoNota(nota: Int): String =
    if (aprobado(nota)) "APROBADO" else "SUSPENSO"

  def maxNota(a: Int, b: Int): Int = {
    if (a > b) a else b
  }

  def clasificacion(nota: Int): String = {
    if (nota >= 9) "EXCELENTE"
    else if (nota >= 7) "NOTABLE"
    else if (nota >= 5) "APROBADO"
    else "SUSPENSO"
  }

  //Recorre estudiantes y notas mostrando estado (versión while)
  def listarEstudiantes(nombres: List[String], calificaciones: Array[Int]): Unit = {
    var i = 0
    while (i < calificaciones.length) {
      val nombre = nombres(i)
      val nota = calificaciones(i)
      println(s"$nombre -> $nota -> ${estadoNota(nota)}")
      i = i + 1
    }
  }

  def listarClasificacion(nombres: List[String], calificaciones: Array[Int]): Unit = {
    var i = 0
    while (i < calificaciones.length) {
      val nombre = nombres(i)
      val nota = calificaciones(i)
      println(s"$nombre -> $nota -> ${clasificacion(nota)}")
      i = i + 1
    }
  }

  def contarAprobados(calificaciones: Array[Int]): Int = {
    var contador = 0
    var i = 0
    while (i < calificaciones.length) {
      if (aprobado(calificaciones(i))) contador = contador + 1
      i = i + 1
    }
    contador
  }

  def contarSuspensos(calificaciones: Array[Int]): Int = {
    var contador = 0
    var i = 0
    while (i < calificaciones.length) {
      if (!aprobado(calificaciones(i))) contador = contador + 1
      i = i + 1
    }
    contador
  }

  def mejorNota(calificaciones: Array[Int]): Int = {
    var mejor = 0
    var i = 0
    while (i < calificaciones.length) {
      mejor = maxNota(mejor, calificaciones(i))
      i = i + 1
    }
    mejor
  }

  def mostrarResumen(calificaciones: Array[Int]): Unit = {
    println("--- Resumen del grupo ---")
    println()
    println(s"Estudiantes: ${calificaciones.length}")
    println(s"Aprobados: ${contarAprobados(calificaciones)}")
    println(s"Suspensos: ${contarSuspensos(calificaciones)}")
    println(s"Mejor nota: ${mejorNota(calificaciones)}")
  }

  //PRIMERA EVALUACIÓN
  println("=== Primera evaluación ===")
  listarEstudiantes(estudiantes, notas)
  println()
  mostrarResumen(notas)

  println()
  println("=== Clasificación primera evaluación ===")
  listarClasificacion(estudiantes, notas)

  //SEGUNDA EVALUACIÓN
  val notasSegundaEvaluacion = Array(9, 5, 8, 7, 6)

  println()
  println("=== Segunda evaluación ===")
  listarEstudiantes(estudiantes, notasSegundaEvaluacion)
  println()
  mostrarResumen(notasSegundaEvaluacion)

  //Comparación de evaluaciones
  val mejorPrimera = mejorNota(notas)
  val mejorSegunda = mejorNota(notasSegundaEvaluacion)
  val aprobadosPrimera = contarAprobados(notas)
  val aprobadosSegunda = contarAprobados(notasSegundaEvaluacion)

  println()
  println("=== Comparación de evaluaciones ===")
  println(s"Mejor nota primera evaluación: $mejorPrimera")
  println(s"Mejor nota segunda evaluación: $mejorSegunda")
  println(s"Aprobados primera evaluación: $aprobadosPrimera")
  println(s"Aprobados segunda evaluación: $aprobadosSegunda")

  if (aprobadosSegunda > aprobadosPrimera) {
    println("El grupo ha mejorado.")
  } else if (aprobadosSegunda < aprobadosPrimera) {
    println("El grupo ha empeorado.")
  } else {
    println("El grupo se ha mantenido igual.")
  }

  //Uso de listas
  val nuevosEstudiantes = "Carlos" :: estudiantes

  println()
  println("=== Lista de estudiantes ===")
  println(s"Lista original: $estudiantes")
  println(s"Lista nueva: $nuevosEstudiantes")
}