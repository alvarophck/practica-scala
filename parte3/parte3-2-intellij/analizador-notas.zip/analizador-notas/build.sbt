scalaVersion := "2.12.20"

lazy val root = rootProject
  .settings(
    name := "analizador-notas",
    libraryDependencies ++= Seq(
      //You can add library dependencies here, for example,
      //"org.scalatest" %% "scalatest" % "3.2.19" % Test,
      //"org.scalameta" %% "munit" % "1.2.3" % Test
    )
  )
